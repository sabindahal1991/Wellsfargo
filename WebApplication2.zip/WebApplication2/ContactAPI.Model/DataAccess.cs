﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace ContactAPI.Model
{
    public class DataAccess
    {
        public string ConnectionString { get; set; }
        public DataAccess()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString;
        }

        public static SqlParameter[] ToParameterArray(Contact contact)
        {
            return new SqlParameter[] { 
                                                new SqlParameter("@ContactName", contact.ContactName)
                                                , new SqlParameter("@Email", contact.Email)
                                                , new SqlParameter("@Address", contact.Address)
                                                , new SqlParameter("@City", contact.City)
                                                , new SqlParameter("@Region", contact.Region ?? (object)DBNull.Value)
                                                , new SqlParameter("@ZipCode", contact.ZipCode)
                                                , new SqlParameter("@Country", contact.Country)
                                                , new SqlParameter("@Phone", contact.Phone)
                                                };
        }

        //public IEnumerable<T> Get(string sqlCommand)
        //{
        //    List<T> tList = new List<T>();
        //    using (IDataReader reader = ExecuteReader(sqlCommand, null, CommandType.Text))
        //    {
        //        while (reader.Read())
        //        {
        //            var entity = PopulateRecord(reader);
        //            tList.Add(entity);
        //        }
        //    }

        //    return tList;
        //}



        //public IEnumerable<T> Get(string sqlCommand, SqlParameter[] parameters
        //                                    , CommandType commandType = CommandType.Text)
        //{
        //    List<T> entityList = null;
        //    using (IDataReader reader = ExecuteReader(sqlCommand, parameters, commandType))
        //    {
        //        entityList = new List<T>();
        //        while (reader.Read())
        //        {
        //            entityList.Add(PopulateRecord(reader));
        //        }
        //    }

        //    return entityList.Count > 0 ? entityList : null;
        //}



        public SqlConnection CreateConnection()
        {
            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();
            return sqlConnection;
        }

        protected SqlDataReader ExecuteReader(string commandText, SqlParameter[] parameters = null
                                            , CommandType commandType = CommandType.Text
                                            , SqlConnection connection = null)
        {
            bool isNewConnection = false;
            if (connection == null || connection.State == ConnectionState.Closed)
            {
                connection = CreateConnection();
                isNewConnection = true;
            }

            try
            {
                SqlCommand command = new SqlCommand(commandText, connection);
                command.CommandType = commandType;
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                var commandBehavior = isNewConnection ? CommandBehavior.CloseConnection : CommandBehavior.Default;
                SqlDataReader reader = command.ExecuteReader(commandBehavior);
                return reader;
            }
            catch (Exception)
            {
                if (isNewConnection && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
                throw;
            }
        }

        protected int ExecuteNonQuery(string commandText, SqlParameter[] parameters = null
                                            , CommandType commandType = CommandType.Text
                                            , SqlConnection connection = null
                                            , SqlTransaction transaction = null)
        {
            bool isLocalConnection = false;
            try
            {
                SqlCommand sqlCommand = BuildSqlCommand(commandText, parameters, commandType, ref connection, transaction, ref isLocalConnection);

                return sqlCommand.ExecuteNonQuery();
            }
            finally
            {
                if (isLocalConnection && connection.State != ConnectionState.Closed)
                    connection.Close();
            }
        }

        protected object ExecuteScalar(string commandText, SqlParameter[] parameters = null
                                            , CommandType commandType = CommandType.Text
                                            , SqlConnection connection = null
                                            , SqlTransaction transaction = null)
        {
            bool isLocalConnection = false;
            try
            {
                SqlCommand sqlCommand = BuildSqlCommand(commandText, parameters, commandType, ref connection, transaction
                                                        , ref isLocalConnection);
                return sqlCommand.ExecuteScalar();
            }
            finally
            {
                if (isLocalConnection && connection.State != ConnectionState.Closed)
                    connection.Close();
            }
        }

        private SqlCommand BuildSqlCommand(string commandText, SqlParameter[] parameters, CommandType commandType
                                            , ref SqlConnection connection
                                            , SqlTransaction transaction
                                            , ref bool isLocalConnection)
        {
            SqlCommand sqlCommand = new SqlCommand(commandText);
            sqlCommand.CommandType = commandType;
            if (parameters != null)
            {
                sqlCommand.Parameters.AddRange(parameters);
            }

            if (connection == null || connection.State == ConnectionState.Closed)
            {
                connection = CreateConnection();
                isLocalConnection = true;
            }

            sqlCommand.Connection = connection;

            if (transaction != null)
                sqlCommand.Transaction = transaction;
            return sqlCommand;
        }


        //public Contact PopulateRecord(IDataReader reader)
        //{
        //    return Get(reader);
        //}

        public IEnumerable<Contact> Get()
        {
            var sqlCommand = "SELECT ContactID,  ContactName, Email "
                            + ", [Address], City, Region, Zipcode, Country, Phone "
                            + " FROM contact";
            SqlDataReader reader = ExecuteReader(sqlCommand);
            List<Contact> contlist = new List<Contact>();
            while (reader.Read())
            {
                var contactobj = new Contact
                {
                    ContactId = reader.GetInt32(reader.GetOrdinal("ContactId")),
                    ContactName = reader.GetString(reader.GetOrdinal("ContactName")),
                    Email = reader.GetString(reader.GetOrdinal("Email")),
                    Address = reader.GetString(reader.GetOrdinal("Address")),
                    City = reader.GetString(reader.GetOrdinal("Address")),
                    Region = reader.GetString(reader.GetOrdinal("Region")),
                    ZipCode = reader.GetString(reader.GetOrdinal("ZipCode")),
                    Country = reader.GetString(reader.GetOrdinal("Country")),
                    Phone = reader.GetString(reader.GetOrdinal("Phone"))

                };
                contlist.Add(contactobj);
            }

            return contlist.AsEnumerable();
        }

        public IEnumerable<Contact> GetbyContactId(int contactId)
        {
            var sqlCommand = "SELECT ContactID,  ContactName, Email "
                            + ", [Address], City, Region, Zipcode, Country, Phone, Fax "
                            + " FROM contact WHERE ContactID = @ContactID";
            var parameters = new SqlParameter[] { new SqlParameter("@ContactID", contactId) };
            SqlDataReader reader = ExecuteReader(sqlCommand);
            List<Contact> contlist = new List<Contact>();
            while (reader.Read())
            {
                var contactobj = new Contact
                {
                    ContactId = reader.GetInt32(reader.GetOrdinal("ContactId")),
                    ContactName = reader.GetString(reader.GetOrdinal("ContactName")),
                    Email = reader.GetString(reader.GetOrdinal("Email")),
                    Address = reader.GetString(reader.GetOrdinal("Address")),
                    City = reader.GetString(reader.GetOrdinal("Address")),
                    Region = reader.GetString(reader.GetOrdinal("Region")),
                    ZipCode = reader.GetString(reader.GetOrdinal("ZipCode")),
                    Country = reader.GetString(reader.GetOrdinal("Country")),
                    Phone = reader.GetString(reader.GetOrdinal("Phone"))

                };
                contlist.Add(contactobj);
            }

            return contlist.AsEnumerable();
 
        }

        public void Add(Contact contact)
        {
            var sqlCommand = ""
                            + "INSERT INTO contact "
                            + " (  ContactName, Email "
                            + ", [Address], City, Region, Zipcode, Country, Phone) "
                            + "VALUES( @ContactName, @Email "
                            + ", @Address, @City, @Region, @ZipCode, @Country, @Phone) ";

            ExecuteNonQuery(sqlCommand, DataAccess.ToParameterArray(contact));
        }

        public void Update(Contact contact)
        {
            var sqlCommand = "UPDATE contact "
                            + " SET ContactName = @ContactName "
                            + "     , Email = @Email, [Address] = @Address "
                            + "     , City = @City, Region = @Region, Zipcode = @Zipcode "
                            + "     , Country = @Country, Phone = @Phone "
                            + " WHERE ContactID = @ContactID ";

            ExecuteNonQuery(sqlCommand, DataAccess.ToParameterArray(contact));
        }

        public void Delete(int contactId)
        {
            var sqlCommand = "DELETE FROM contact WHERE ContactID = @ContactID ";
            var parameters = new SqlParameter[] { new SqlParameter("@ContactID", contactId) };

            ExecuteNonQuery(sqlCommand, parameters);
        }
    }
}

