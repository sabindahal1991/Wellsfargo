﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Net.Http;

namespace ContactAPI.Model
{
    public class ContactService
    {
        private DataAccess _DataAccess;

        /// <summary>
        /// contactlist stores in-memory copy of repository (cached).
        /// </summary>
        private static List<Contact> _contactList;

        public ContactService()
        {
            _DataAccess = new DataAccess();
        }

        public IEnumerable<Contact> Get()
        {
            if (_contactList == null)
            {
                _contactList = _DataAccess.Get().ToList();
            }
            return _contactList;
        }

        public IEnumerable<Contact> Get(int contactId)
        {
            if (_contactList != null)
                return _contactList.Where(c => c.ContactId == contactId);
            else return _DataAccess.GetbyContactId(contactId);
        }

        public void Add(Contact contact)
        {
            _DataAccess.Add(contact);
            if (_contactList != null)
                _contactList.Add(contact);
        }

        public void Update(Contact contact)
        {
            _DataAccess.Update(contact);
            if (_contactList != null)
            {
                _contactList.Remove(_contactList.FirstOrDefault(c => c.ContactId == contact.ContactId));
                _contactList.Add(contact);
            }
        }

        public void Delete(int contactId)
        {
            _DataAccess.Delete(contactId);
            if (_contactList != null)
            {
                _contactList.Remove(_contactList.Where(c => c.ContactId == contactId).FirstOrDefault());
            }
        }

        public void ValidateZipCode(Contact contact)
        {
            string url = @"https://www.zipcodeapi.com/rest/ELvHn5VnbRnVWADOq1YQMbkcWt4A4RtugEwGiYBCfIaKn6bSKH6W2APmkPPJtilj/city-zips.json/chicago/IL";

            WebClient client = new WebClient();

            Stream stream = client.OpenRead(url);

            StreamReader rdr = new StreamReader(stream);

        }

    }
}
