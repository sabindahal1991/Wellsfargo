﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ContactAPI.Model;
using System.IO;
using Newtonsoft.Json;
namespace WebApplication2.Controllers
{
    public class ContactController : ApiController
    {
        private ContactService _contactService;

        public ContactController()
        {
            _contactService = new ContactService();
        }

        // GET: api/Contact
        public HttpResponseMessage Get()
        {
            var Contacts = _contactService.Get();
            if (Contacts != null)
                return Request.CreateResponse(HttpStatusCode.OK, Contacts);
            else return Request.CreateErrorResponse(HttpStatusCode.NotFound
                                    , "No Contacts found");
        }

        // GET: api/Contact/5
        public HttpResponseMessage Get(int id)
        {
            var Contact = _contactService.Get(id);
            if (Contact != null)
                return Request.CreateResponse(HttpStatusCode.OK, Contact);
            else return Request.CreateErrorResponse(HttpStatusCode.NotFound
                                    , "Contact with Id " + id + " does not exist");
        }


        // POST: api/Contact
        public HttpResponseMessage Post([FromBody]Contact Contact)
        {
            //_contactService.ValidateZipCode(Contact);
            _contactService.Add(Contact);

            var message = Request.CreateResponse(HttpStatusCode.Created);
            message.Headers.Location = new Uri(Request.RequestUri + Contact.ContactName);
            return message;
        }

        // PUT: api/Contact/5
        public HttpResponseMessage Put([FromBody]Contact Contact)
        {
            _contactService.Update(Contact);
            return Request.CreateResponse(HttpStatusCode.OK, string.Empty);
        }

        // DELETE: api/Contact/5
        public HttpResponseMessage Delete(int id)
        {
            _contactService.Delete(id);
            return Request.CreateResponse(HttpStatusCode.OK, string.Empty);
        }
    }
}
